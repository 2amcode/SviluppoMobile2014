package com.paad.preferences;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.widget.Toast;

public class MyActivity extends Activity implements
		OnSharedPreferenceChangeListener {

	private static final int SHOW_PREFERENCES = 0;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		SharedPreferences prefs = PreferenceManager
				.getDefaultSharedPreferences(this);
		prefs.registerOnSharedPreferenceChangeListener(this);

		/**
		 * Listing 7-3: Runtime selection of pre- or post-Honeycomb Preference
		 * Activities
		 */
		Class c = Build.VERSION.SDK_INT < Build.VERSION_CODES.HONEYCOMB ? MyPreferenceActivity.class
				: MyFragmentPreferenceActivity.class;

		Intent i = new Intent(this, c);
		startActivityForResult(i, SHOW_PREFERENCES);
	}

	@Override
	public void onSharedPreferenceChanged(SharedPreferences arg0, String arg1) {
		// TODO arg1 � la key che devo controllare
		Toast.makeText(this, "PREFERENCE " + arg1 +  " CAMBIATA", Toast.LENGTH_LONG).show();
	}
}