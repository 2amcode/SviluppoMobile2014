/** Automatically generated file. DO NOT MODIFY */
package it.apogeo.android.cap08.completepreferencestest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}