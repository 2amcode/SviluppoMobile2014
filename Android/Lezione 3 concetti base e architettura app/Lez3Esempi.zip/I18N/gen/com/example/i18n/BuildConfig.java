/** Automatically generated file. DO NOT MODIFY */
package com.example.i18n;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}