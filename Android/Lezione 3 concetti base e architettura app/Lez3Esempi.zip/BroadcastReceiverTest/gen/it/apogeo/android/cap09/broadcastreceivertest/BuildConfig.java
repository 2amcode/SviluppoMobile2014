/** Automatically generated file. DO NOT MODIFY */
package it.apogeo.android.cap09.broadcastreceivertest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}