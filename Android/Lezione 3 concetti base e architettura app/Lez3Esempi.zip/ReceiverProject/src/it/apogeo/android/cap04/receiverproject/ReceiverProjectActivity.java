package it.apogeo.android.cap04.receiverproject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class ReceiverProjectActivity extends Activity {
	
	private static final String TAG = ReceiverProjectActivity.class.getSimpleName();
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        Intent intent = getIntent();
        // getIntent torna sempre un intent!!!
        String action = intent.getAction();
        Log.i(TAG, action);
        Bundle extras = intent.getExtras();
        if (extras.containsKey("prop1")) {
        	TextView t = (TextView) findViewById(R.id.testo);
        	t.setText(extras.getString("prop1"));
        }
    }
}