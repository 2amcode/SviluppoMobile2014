package it.apogeo.android.cap04.esplicitintenttest;

import android.app.Activity;
import android.os.Bundle;

/**
 * @author MASSIMO
 *
 */
public class SecondActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
	}
	
	

}
