ToastGravity
============

AndroidWorld.it - DevCorner: Un'applicazione d'esempio per testare gli Spinner e i Toast
