package com.paad.fragments;

import com.paad.fragments.SeasonFragment.OnSeasonSelectedListener;

import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class MyFragmentActivity extends Activity implements OnSeasonSelectedListener{

  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    // Inflate the layout containing the Fragment containers
    setContentView(R.layout.fragment_container_layout);
    
    FragmentManager fm = getFragmentManager();

    // Check to see if the Fragment back stack has been populated
    // If not, create and populate the layout.
    DetailsFragment detailsFragment = 
      (DetailsFragment)fm.findFragmentById(R.id.details_container);
    
    
    
    if (detailsFragment == null) {
       FragmentTransaction ft = fm.beginTransaction(); 
       ft.add(R.id.details_container, new SeasonFragment());
       ft.add(R.id.ui_container, new MyListFragment(), "TAG_FRAGMENT");
       ft.commit();
     }
    
    //MyListFragment mlf = (MyListFragment) fm.findFragmentByTag("TAG_FRAGMENT");
  }
  
  public void clicca(View v) {
	  Log.e("TAG", "pippo");
  }

@Override
public void onSeasonSelected(Season season) {
	// TODO Auto-generated method stub
	Log.e("ONSEASONSELECTED", "passato per ONSEASONSELECTED");
}
}
