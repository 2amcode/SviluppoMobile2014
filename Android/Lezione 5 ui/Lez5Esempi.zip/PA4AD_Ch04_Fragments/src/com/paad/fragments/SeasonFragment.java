package com.paad.fragments;

import android.app.Activity;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView.FindListener;
import android.widget.Button;

/**
 * MOVED TO PA4AD_Ch04_Seasons
 */
public class SeasonFragment extends Fragment {

  public interface OnSeasonSelectedListener {
    public void onSeasonSelected(Season season);
  }
    
  private OnSeasonSelectedListener onSeasonSelectedListener;
  private Season currentSeason;

  @Override
  public void onAttach(Activity activity) {
    super.onAttach(activity);
      
    try {
      onSeasonSelectedListener = (OnSeasonSelectedListener)activity;
    } catch (ClassCastException e) {
      throw new ClassCastException(activity.toString() + 
                " must implement OnSeasonSelectedListener");
    }
  }

  @Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		super.onCreateView(inflater, container, savedInstanceState);
		
		return inflater.inflate(R.layout.season_fragment, container, false);		
	}
  
  @Override
	public void onActivityCreated(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);
		
		Button b = (Button) getActivity().findViewById(R.id.button1);
		b.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				setSeason(new Season());
			}
		});
		
	}
  
  private void setSeason(Season season) {
    currentSeason = season;
    onSeasonSelectedListener.onSeasonSelected(season);
  }
  
}
