package it.kynetics.restcall;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.entity.BufferedHttpEntity;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.AbstractHttpClient;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.util.EntityUtils;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;

public class MainActivity extends Activity {

	private static final String TAG = MainActivity.class.getSimpleName();
	
	@SuppressWarnings("unchecked")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		new RestConnection().execute();
	}
	
	// chiamata che produce una NetworkOnMainThreadException (no operazioni di rete nel main thread)
	// SOLUZIONE FARLOCCA AMBIENTE DI SVILUPPO
	// StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
	// StrictMode.setThreadPolicy(policy);
	private void callRestful() {
		try {
            DefaultHttpClient client = new DefaultHttpClient();
            HttpGet request = new HttpGet("http://www.google.com");
            HttpResponse response = client.execute(request);
            Log.d(TAG, response.toString());
        } catch (ClientProtocolException e) {
            Log.d("HTTPCLIENT", e.getLocalizedMessage());
        } catch (IOException e) {
            Log.d("HTTPCLIENT", e.getLocalizedMessage());
        }
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	private class RestConnection extends AsyncTask {
		 
        @Override
        protected Object doInBackground(Object... arg0) {
            connect();
            return null;
        }
 
    }
 
    private void connect() {
        try {
        	String result;
        	HttpClient httpclient = new DefaultHttpClient();  
            HttpGet request = new HttpGet("https://www.google.com");
            // request.addHeader("deviceId", "1");  
            ResponseHandler<String> handler = new BasicResponseHandler();
            result = httpclient.execute(request, handler);
            Log.i(TAG, result);
            
            HttpResponse response = httpclient.execute(request);
            
            if (response != null && (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK)) {
                BufferedHttpEntity bufferedHttpEntity = new BufferedHttpEntity(response.getEntity());
                InputStream resultIS = bufferedHttpEntity.getContent();
                BufferedReader in = new BufferedReader(new InputStreamReader(resultIS));
                String inputLine;
                while ((inputLine = in.readLine()) != null)
                    System.out.println(inputLine);
                in.close();
            } else {
                // insert error handling
            }
            httpclient.getConnectionManager().shutdown();
        } catch (ClientProtocolException e) {
        	Log.e(TAG, e.getLocalizedMessage(), e);
        } catch (IOException e) {
        	Log.e(TAG, e.getLocalizedMessage(), e);
        }
    }
    
    private void connectWithBasicAuthentication() {
    	String username = "user";
        String host = "host";
        String password = "MyPassHere";
        String urlBasePath = "http://" + username + ".host.com/";
        String urlApiCall_FindAllRepositories = urlBasePath
                + "repositories.xml";
        try {
            HttpClient client = new DefaultHttpClient();
            AuthScope as = new AuthScope(host, 443);
            UsernamePasswordCredentials upc = new UsernamePasswordCredentials(username, password);
            ((AbstractHttpClient) client).getCredentialsProvider().setCredentials(as, upc);
            BasicHttpContext localContext = new BasicHttpContext();
            BasicScheme basicAuth = new BasicScheme();
            localContext.setAttribute("preemptive-auth", basicAuth);
            HttpHost targetHost = new HttpHost(host, 443, "https");
            HttpGet httpget = new HttpGet(urlApiCall_FindAllRepositories);
            httpget.setHeader("Content-Type", "application/xml");
            HttpResponse response = client.execute(targetHost, httpget, localContext);
            HttpEntity entity = response.getEntity();
            Object content = EntityUtils.toString(entity);
            Log.d(TAG, "OK: " + content.toString());
        } catch (Exception e) {
            e.printStackTrace();
            Log.d(TAG, "Error: " + e.getMessage());
        }
    }
	
}
