/** Automatically generated file. DO NOT MODIFY */
package it.apogeo.android.cap09.remoteserviceclient;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}