/** Automatically generated file. DO NOT MODIFY */
package it.apogeo.android.cap09.remoteservicetest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}