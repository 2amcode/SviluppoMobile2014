package it.apogeo.android.cap03.resourcelayout;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class ResourceLayoutActivity extends Activity {
	// COntatore
	private int counter = 0;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		// Otteniamo il riferimento al Button
		Button pressButton = (Button) findViewById(R.id.pressButton);
		// Otteniamo il riferimento alla TextView
		final TextView outputView = (TextView) findViewById(R.id.output);
		// Ascoltiamo l'evento di pressione associato al pulsante
		pressButton.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				outputView.setText("Click # " + counter++);
			}

		});

    }
}