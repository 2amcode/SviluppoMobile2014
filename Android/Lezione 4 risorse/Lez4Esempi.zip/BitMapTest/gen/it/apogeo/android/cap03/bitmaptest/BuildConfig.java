/** Automatically generated file. DO NOT MODIFY */
package it.apogeo.android.cap03.bitmaptest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}